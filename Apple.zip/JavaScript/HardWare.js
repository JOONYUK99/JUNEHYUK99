let text=["IPAD",
          "Apple Watch",
          "Iphone",
          "Mac"];
let commentDiv;

function init() {
	commentDiv = document.getElementById("commentDiv");	

	let liArray = document.getElementsByTagName("li");
	for(let i=0; i<liArray.length; i++) {
		liArray[i].addEventListener("mouseover", over, false);
		liArray[i].addEventListener("mouseout", hideCommentDiv, false);	
	}
}

function over(e) {
	let n=0;
	switch(e.target.id) {
		case "l0" : n = 0; break;
		case "l1" : n = 1; break;
		case "l2" : n = 2; break;
		case "l3" : n = 3; break;
	}
	setCommentDiv(text[n], e);	
}

function setCommentDiv(comment, e) {
	commentDiv.innerHTML = comment;
	commentDiv.style.left = e.clientX + "px";
	commentDiv.style.top = e.clientY + "px";
	commentDiv.style.border = "1px solid yellowgreen";
	commentDiv.style.background = "aliceblue";
	commentDiv.style.visibility = "visible";
	commentDiv.style.width = "200px";
	commentDiv.style.height = "80px";
}

function hideCommentDiv() {
	commentDiv.style.visibility = "hidden";
}